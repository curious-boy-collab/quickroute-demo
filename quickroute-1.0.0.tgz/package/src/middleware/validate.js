const mongoose = require('mongoose');
const AppError = require('../errors/AppError');

// Forbidden fields that can never be modified directly via request body
const FORBIDDEN_FIELDS = ['_id', '__v', 'createdAt', 'updatedAt'];

/**
 * Filter object to only allowed fields and strip forbidden fields
 * @param {Object} data
 * @param {Array<string>} [allowedFields]
 * @returns {Object}
 */
function sanitizePayload(data, allowedFields = null) {
  if (!data || typeof data !== 'object') {
    return {};
  }

  const sanitized = {};

  for (const [key, value] of Object.entries(data)) {
    // Block internal fields
    if (FORBIDDEN_FIELDS.includes(key)) {
      continue;
    }

    // If allowedFields is defined, only permit whitelisted fields
    if (Array.isArray(allowedFields) && allowedFields.length > 0) {
      if (!allowedFields.includes(key)) {
        continue;
      }
    }

    sanitized[key] = value;
  }

  return sanitized;
}

/**
 * Validate MongoDB ObjectId in request parameters
 * @param {string} [paramName='id']
 */
function validateId(paramName = 'id') {
  return (req, res, next) => {
    const id = req.params[paramName];
    if (!id || !mongoose.Types.ObjectId.isValid(id)) {
      return next(new AppError('Invalid ID format', 400));
    }
    next();
  };
}

/**
 * Validate and sanitize create payload
 * @param {Object} options
 * @param {Array<string>} [options.allowedFields]
 * @param {Array<string>} [options.requiredFields]
 */
function validateCreate(options = {}) {
  const { allowedFields, requiredFields } = options;

  return (req, res, next) => {
    if (!req.body || typeof req.body !== 'object' || Array.isArray(req.body)) {
      return next(new AppError('Request body must be a JSON object', 400));
    }

    // Check required fields
    if (Array.isArray(requiredFields) && requiredFields.length > 0) {
      for (const field of requiredFields) {
        if (
          req.body[field] === undefined ||
          req.body[field] === null ||
          req.body[field] === ''
        ) {
          return next(new AppError(`Field '${field}' is required`, 400));
        }
      }
    }

    // Sanitize body (strip forbidden and non-allowed fields)
    req.body = sanitizePayload(req.body, allowedFields);

    next();
  };
}

/**
 * Validate and sanitize update payload (PUT / PATCH)
 * @param {Object} options
 * @param {Array<string>} [options.allowedFields]
 */
function validateUpdate(options = {}) {
  const { allowedFields } = options;

  return (req, res, next) => {
    if (!req.body || typeof req.body !== 'object' || Array.isArray(req.body)) {
      return next(new AppError('Request body must be a JSON object', 400));
    }

    // Sanitize body
    const sanitized = sanitizePayload(req.body, allowedFields);

    if (Object.keys(sanitized).length === 0) {
      return next(new AppError('No valid fields provided for update', 400));
    }

    req.body = sanitized;
    next();
  };
}

module.exports = {
  FORBIDDEN_FIELDS,
  sanitizePayload,
  validateId,
  validateCreate,
  validateUpdate
};
