const express = require('express');
const { createController } = require('./controller');
const { validateId, validateCreate, validateUpdate } = require('../middleware/validate');

/**
 * Helper to normalize middleware into an array
 * @param {Function|Array<Function>} mw
 * @returns {Array<Function>}
 */
function normalizeMiddleware(mw) {
  if (!mw) return [];
  if (Array.isArray(mw)) return mw.filter((fn) => typeof fn === 'function');
  if (typeof mw === 'function') return [mw];
  return [];
}

/**
 * Create Express Router with preconfigured CRUD endpoints for a Mongoose model
 * @param {Object} options
 * @param {Object} options.model - Mongoose model (required)
 * @param {string} [options.name] - Resource name (e.g. "users")
 * @param {Array<string>} [options.searchableFields] - Fields enabled for search
 * @param {Array<string>} [options.allowedFields] - Whitelisted body fields
 * @param {Array<string>} [options.requiredFields] - Required fields on create
 * @param {Array<string>} [options.sortableFields] - Whitelisted sort fields
 * @param {Object} [options.routes] - Enabled/disabled routes { create, getAll, getOne, update, delete }
 * @param {Object} [options.middleware] - Middleware map { all, create, getAll, getOne, update, delete }
 * @param {Object|string} [options.defaultSort] - Default sort option
 * @returns {express.Router}
 */
function createRoutes(options = {}) {
  if (!options || typeof options !== 'object') {
    throw new Error('QuickRoute.create requires an options object');
  }

  const { model } = options;
  if (!model || typeof model !== 'function') {
    throw new Error('QuickRoute.create requires a valid Mongoose model in options.model');
  }

  const router = express.Router();
  const controller = createController(model, options);

  // Default routes config: all enabled unless explicitly set to false
  const enabledRoutes = {
    getAll: true,
    getOne: true,
    create: true,
    update: true,
    delete: true,
    ...(options.routes || {})
  };

  // Middleware normalization
  const mwConfig = options.middleware || {};
  const globalMW = normalizeMiddleware(mwConfig.all);
  const getAllMW = [...globalMW, ...normalizeMiddleware(mwConfig.getAll)];
  const getOneMW = [...globalMW, ...normalizeMiddleware(mwConfig.getOne)];
  const createMW = [...globalMW, ...normalizeMiddleware(mwConfig.create)];
  const updateMW = [...globalMW, ...normalizeMiddleware(mwConfig.update)];
  const deleteMW = [...globalMW, ...normalizeMiddleware(mwConfig.delete)];

  // Validation middlewares
  const idValidation = validateId('id');
  const createValidation = validateCreate({
    allowedFields: options.allowedFields,
    requiredFields: options.requiredFields
  });
  const updateValidation = validateUpdate({
    allowedFields: options.allowedFields
  });

  // GET / - Read all
  if (enabledRoutes.getAll) {
    router.get('/', ...getAllMW, controller.getAll);
  }

  // POST / - Create
  if (enabledRoutes.create) {
    router.post('/', ...createMW, createValidation, controller.create);
  }

  // GET /:id - Read one
  if (enabledRoutes.getOne) {
    router.get('/:id', ...getOneMW, idValidation, controller.getOne);
  }

  // PUT /:id - Full update
  if (enabledRoutes.update) {
    router.put('/:id', ...updateMW, idValidation, updateValidation, controller.update);
    // PATCH /:id - Partial update
    router.patch('/:id', ...updateMW, idValidation, updateValidation, controller.update);
  }

  // DELETE /:id - Delete
  if (enabledRoutes.delete) {
    router.delete('/:id', ...deleteMW, idValidation, controller.deleteDoc);
  }

  return router;
}

module.exports = createRoutes;
