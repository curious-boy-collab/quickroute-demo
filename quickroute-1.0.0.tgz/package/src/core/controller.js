const asyncHandler = require('../utils/asyncHandler');
const AppError = require('../errors/AppError');
const { getPaginationParams, formatPagination } = require('../utils/pagination');
const { buildSearchQuery, buildSort } = require('../utils/search');

/**
 * Format singular capitalized resource name for consistent error messages
 */
function getResourceLabel(options = {}, model = {}) {
  if (options.singularName) {
    return options.singularName.charAt(0).toUpperCase() + options.singularName.slice(1);
  }
  if (options.name) {
    const raw = options.name.endsWith('s') ? options.name.slice(0, -1) : options.name;
    return raw.charAt(0).toUpperCase() + raw.slice(1);
  }
  if (model.modelName) {
    return model.modelName;
  }
  return 'Resource';
}

/**
 * Create CRUD controller for a Mongoose model
 * @param {Object} model - Mongoose Model
 * @param {Object} options - QuickRoute configuration options
 */
function createController(model, options = {}) {
  const resourceLabel = getResourceLabel(options, model);
  const searchableFields = options.searchableFields || [];
  const sortableFields = options.sortableFields || null;
  const defaultSort = options.defaultSort || { createdAt: -1 };

  return {
    /**
     * Create a new document
     * POST /
     */
    create: asyncHandler(async (req, res) => {
      const doc = await model.create(req.body);
      res.status(201).json({
        success: true,
        data: doc
      });
    }),

    /**
     * Get all documents with pagination, search, and sorting
     * GET /
     */
    getAll: asyncHandler(async (req, res) => {
      const { page, limit, skip } = getPaginationParams(req.query, options);

      // Build search query criteria
      const searchQuery = buildSearchQuery(req.query.search, searchableFields);

      // Extract optional exact-match filter criteria from allowed query fields
      const filterQuery = {};
      const reservedKeys = ['page', 'limit', 'sort', 'search'];
      const allowedFilters = options.filterableFields || options.allowedFields || [];

      for (const [key, val] of Object.entries(req.query)) {
        if (!reservedKeys.includes(key) && (allowedFilters.length === 0 || allowedFilters.includes(key))) {
          // Prevent MongoDB query selector injection (e.g. { $gt: "" })
          if (typeof val === 'string' || typeof val === 'number' || typeof val === 'boolean') {
            filterQuery[key] = val;
          }
        }
      }

      // Combine search and filter queries safely
      let queryCriteria = {};
      if (Object.keys(searchQuery).length > 0 && Object.keys(filterQuery).length > 0) {
        queryCriteria = { $and: [searchQuery, filterQuery] };
      } else if (Object.keys(searchQuery).length > 0) {
        queryCriteria = searchQuery;
      } else if (Object.keys(filterQuery).length > 0) {
        queryCriteria = filterQuery;
      }

      // Total count
      const total = await model.countDocuments(queryCriteria);

      // Safe sort
      const sort = buildSort(req.query.sort, sortableFields, defaultSort);

      // Fetch documents
      const docs = await model.find(queryCriteria).sort(sort).skip(skip).limit(limit);

      res.status(200).json({
        success: true,
        data: docs,
        pagination: formatPagination(page, limit, total)
      });
    }),

    /**
     * Get single document by ID
     * GET /:id
     */
    getOne: asyncHandler(async (req, res) => {
      const doc = await model.findById(req.params.id);
      if (!doc) {
        throw new AppError(`${resourceLabel} not found`, 404);
      }

      res.status(200).json({
        success: true,
        data: doc
      });
    }),

    /**
     * Update document by ID (PUT / PATCH)
     * PUT/:id or PATCH/:id
     */
    update: asyncHandler(async (req, res) => {
      const doc = await model.findByIdAndUpdate(req.params.id, req.body, {
        new: true,
        runValidators: true
      });

      if (!doc) {
        throw new AppError(`${resourceLabel} not found`, 404);
      }

      res.status(200).json({
        success: true,
        data: doc
      });
    }),

    /**
     * Delete document by ID
     * DELETE /:id
     */
    deleteDoc: asyncHandler(async (req, res) => {
      const doc = await model.findByIdAndDelete(req.params.id);

      if (!doc) {
        throw new AppError(`${resourceLabel} not found`, 404);
      }

      res.status(200).json({
        success: true,
        message: `${resourceLabel} deleted successfully`
      });
    })
  };
}

module.exports = {
  createController,
  getResourceLabel
};
