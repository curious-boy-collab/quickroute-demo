/**
 * Escape regular expression special characters to prevent ReDoS / injection
 * @param {string} str
 * @returns {string}
 */
function escapeRegex(str) {
  if (typeof str !== 'string') return '';
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Build MongoDB search query object from search query parameter
 * @param {string} searchTerm - User provided search term
 * @param {Array<string>} searchableFields - Allowed fields to search on
 * @returns {Object} MongoDB query criteria
 */
function buildSearchQuery(searchTerm, searchableFields = []) {
  if (!searchTerm || typeof searchTerm !== 'string' || !Array.isArray(searchableFields) || searchableFields.length === 0) {
    return {};
  }

  const trimmed = searchTerm.trim();
  if (!trimmed) {
    return {};
  }

  const escaped = escapeRegex(trimmed);
  const conditions = searchableFields.map((field) => ({
    [field]: { $regex: escaped, $options: 'i' }
  }));

  return conditions.length === 1 ? conditions[0] : { $or: conditions };
}

/**
 * Build safe MongoDB sort object from sort query parameter
 * @param {string} sortParam - e.g. "name", "-createdAt", "name,-createdAt"
 * @param {Array<string>} sortableFields - Allowed sortable fields
 * @param {string|Object} defaultSort - Default sort, e.g. "-createdAt"
 * @returns {Object} MongoDB sort specification
 */
function buildSort(sortParam, sortableFields = null, defaultSort = { createdAt: -1 }) {
  if (!sortParam || typeof sortParam !== 'string') {
    return defaultSort;
  }

  const fields = sortParam.split(',').map((s) => s.trim()).filter(Boolean);
  const sortObj = {};

  for (const item of fields) {
    let order = 1;
    let field = item;

    if (item.startsWith('-')) {
      order = -1;
      field = item.substring(1);
    } else if (item.startsWith('+')) {
      order = 1;
      field = item.substring(1);
    }

    // Security check: ensure field name is safe alphanumeric/dots
    if (!/^[a-zA-Z0-9_.]+$/.test(field)) {
      continue;
    }

    // If sortableFields is specified, only allow fields in the whitelist
    if (Array.isArray(sortableFields) && sortableFields.length > 0) {
      if (!sortableFields.includes(field)) {
        continue;
      }
    }

    sortObj[field] = order;
  }

  return Object.keys(sortObj).length > 0 ? sortObj : defaultSort;
}

module.exports = {
  escapeRegex,
  buildSearchQuery,
  buildSort
};
