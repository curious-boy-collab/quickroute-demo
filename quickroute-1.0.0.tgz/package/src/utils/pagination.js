/**
 * Parse and validate pagination parameters
 * @param {Object} query - Express req.query
 * @param {Object} options - Pagination options
 * @returns {Object} { page, limit, skip }
 */
function getPaginationParams(query = {}, options = {}) {
  const defaultPage = options.defaultPage || 1;
  const defaultLimit = options.defaultLimit || 10;
  const maxLimit = options.maxLimit || 100;

  let page = parseInt(query.page, 10);
  if (isNaN(page) || page < 1) {
    page = defaultPage;
  }

  let limit = parseInt(query.limit, 10);
  if (isNaN(limit) || limit < 1) {
    limit = defaultLimit;
  } else if (limit > maxLimit) {
    limit = maxLimit;
  }

  const skip = (page - 1) * limit;

  return { page, limit, skip };
}

/**
 * Format standard pagination response payload
 * @param {number} page
 * @param {number} limit
 * @param {number} total
 * @returns {Object}
 */
function formatPagination(page, limit, total) {
  const totalPages = limit > 0 ? Math.ceil(total / limit) : 0;
  return {
    page,
    limit,
    total,
    totalPages
  };
}

module.exports = {
  getPaginationParams,
  formatPagination
};
