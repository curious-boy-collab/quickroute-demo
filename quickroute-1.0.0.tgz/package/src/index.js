const createRoutes = require('./core/createRoutes');
const { createController } = require('./core/controller');
const AppError = require('./errors/AppError');
const errorHandler = require('./middleware/errorHandler');
const asyncHandler = require('./utils/asyncHandler');
const { validateId, validateCreate, validateUpdate } = require('./middleware/validate');
const { getPaginationParams, formatPagination } = require('./utils/pagination');
const { buildSearchQuery, buildSort, escapeRegex } = require('./utils/search');

const QuickRoute = {
  create: createRoutes
};

module.exports = {
  QuickRoute,
  createRoutes,
  createController,
  AppError,
  errorHandler,
  asyncHandler,
  validateId,
  validateCreate,
  validateUpdate,
  getPaginationParams,
  formatPagination,
  buildSearchQuery,
  buildSort,
  escapeRegex
};

// Also attach QuickRoute directly to module.exports for default-like CJS access
module.exports.default = QuickRoute;
