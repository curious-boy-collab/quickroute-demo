import cjsModule from './index.js';

export const QuickRoute = cjsModule.QuickRoute;
export const createRoutes = cjsModule.createRoutes;
export const createController = cjsModule.createController;
export const AppError = cjsModule.AppError;
export const errorHandler = cjsModule.errorHandler;
export const asyncHandler = cjsModule.asyncHandler;
export const validateId = cjsModule.validateId;
export const validateCreate = cjsModule.validateCreate;
export const validateUpdate = cjsModule.validateUpdate;
export const getPaginationParams = cjsModule.getPaginationParams;
export const formatPagination = cjsModule.formatPagination;
export const buildSearchQuery = cjsModule.buildSearchQuery;
export const buildSort = cjsModule.buildSort;
export const escapeRegex = cjsModule.escapeRegex;

export default QuickRoute;
